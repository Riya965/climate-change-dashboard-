import { useEffect, useRef, useState } from 'react'
import { SHEET_CSV_URL, REFRESH_INTERVAL_MS } from '../data/liveConfig.js'
import { fetchLiveSurveyData } from '../data/liveSurvey.js'
import * as staticData from '../data/surveyData.js'

const STATIC_SNAPSHOT = {
  TOTAL_RESPONDENTS: staticData.TOTAL_RESPONDENTS,
  AWARENESS_RESPONDENTS: staticData.AWARENESS_RESPONDENTS,
  HEARD_ABOUT_PERCENT: staticData.HEARD_ABOUT_PERCENT,
  SERIOUS_AGREE_PERCENT: staticData.SERIOUS_AGREE_PERCENT,
  AVERAGE_KNOWLEDGE_RATING: staticData.AVERAGE_KNOWLEDGE_RATING,
  ageData: staticData.ageData,
  genderData: staticData.genderData,
  occupationData: staticData.occupationData,
  heardAboutData: staticData.heardAboutData,
  knowledgeData: staticData.knowledgeData,
  sourceData: staticData.sourceData,
  seriousnessData: staticData.seriousnessData,
  concernData: staticData.concernData,
  keyInsights: staticData.keyInsights,
}

// Provides survey data to any page. If SHEET_CSV_URL is set in
// src/data/liveConfig.js, it fetches real responses from the connected
// Google Sheet (and re-fetches on an interval so new Form submissions show
// up without a manual redeploy). Otherwise it falls back to the fixed demo
// numbers in src/data/surveyData.js so the site still works out of the box.
export function useSurveyData() {
  const [state, setState] = useState({
    data: STATIC_SNAPSHOT,
    isLive: false,
    loading: Boolean(SHEET_CSV_URL),
    error: null,
    lastUpdated: null,
  })
  const timerRef = useRef(null)

  useEffect(() => {
    if (!SHEET_CSV_URL) return undefined

    let cancelled = false

    async function load() {
      try {
        const live = await fetchLiveSurveyData(SHEET_CSV_URL)
        if (cancelled) return
        setState({ data: live, isLive: true, loading: false, error: null, lastUpdated: new Date() })
      } catch (err) {
        if (cancelled) return
        // Keep showing the last good data (live or static) — don't blank the dashboard on a failed refresh.
        setState((prev) => ({ ...prev, loading: false, error: err.message || 'Could not load live data.' }))
      }
    }

    load()
    if (REFRESH_INTERVAL_MS > 0) {
      timerRef.current = setInterval(load, REFRESH_INTERVAL_MS)
    }

    return () => {
      cancelled = true
      if (timerRef.current) clearInterval(timerRef.current)
    }
  }, [])

  const refresh = () => {
    if (!SHEET_CSV_URL) return
    setState((prev) => ({ ...prev, loading: true }))
    fetchLiveSurveyData(SHEET_CSV_URL)
      .then((live) => setState({ data: live, isLive: true, loading: false, error: null, lastUpdated: new Date() }))
      .catch((err) => setState((prev) => ({ ...prev, loading: false, error: err.message || 'Could not load live data.' })))
  }

  return { ...state, refresh, isConfigured: Boolean(SHEET_CSV_URL) }
}
