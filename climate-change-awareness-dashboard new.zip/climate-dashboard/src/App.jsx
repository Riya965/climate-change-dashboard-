import { HashRouter, Routes, Route } from 'react-router-dom'
import Navbar from './components/Navbar.jsx'
import Footer from './components/Footer.jsx'
import Home from './pages/Home.jsx'
import Dashboard from './pages/Dashboard.jsx'
import ClimateInfo from './pages/ClimateInfo.jsx'
import ClimateAction from './pages/ClimateAction.jsx'
import About from './pages/About.jsx'

function ScrollToTopLayout({ children }) {
  return children
}

export default function App() {
  return (
    <HashRouter>
      <Navbar />
      <ScrollToTopLayout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/climate-info" element={<ClimateInfo />} />
          <Route path="/climate-action" element={<ClimateAction />} />
          <Route path="/about" element={<About />} />
        </Routes>
      </ScrollToTopLayout>
      <Footer />
    </HashRouter>
  )
}
