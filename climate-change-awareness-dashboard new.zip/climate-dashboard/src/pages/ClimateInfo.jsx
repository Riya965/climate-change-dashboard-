import {
  Flame, TreeDeciduous, Factory, Car, Wheat, Zap,
  Thermometer, Waves, Sun, CloudRain, Sprout, PawPrint, BookOpen,
} from 'lucide-react'

const causes = [
  { icon: <Flame size={22} />, title: 'Fossil Fuels', text: 'Burning coal, oil, and gas for energy releases large amounts of carbon dioxide into the atmosphere.' },
  { icon: <TreeDeciduous size={22} />, title: 'Deforestation', text: 'Cutting down forests reduces the planet\u2019s ability to absorb CO2 and releases stored carbon.' },
  { icon: <Factory size={22} />, title: 'Industrial Emissions', text: 'Factories and manufacturing processes emit greenhouse gases and pollutants at large scale.' },
  { icon: <Car size={22} />, title: 'Transportation', text: 'Cars, trucks, ships, and planes burn fossil fuels, making transport a major emissions source.' },
  { icon: <Wheat size={22} />, title: 'Agriculture', text: 'Livestock farming and fertilizer use release methane and nitrous oxide, potent greenhouse gases.' },
  { icon: <Zap size={22} />, title: 'Energy Production', text: 'Generating electricity from non-renewable sources remains one of the largest contributors to emissions.' },
]

const effects = [
  { icon: <Thermometer size={22} />, title: 'Rising Temperatures', text: 'Global average temperatures continue to climb, disrupting ecosystems and weather patterns.' },
  { icon: <Waves size={22} />, title: 'Sea-Level Rise', text: 'Melting ice sheets and glaciers cause oceans to rise, threatening coastal communities.' },
  { icon: <Sun size={22} />, title: 'Heatwaves', text: 'More frequent and intense heatwaves put pressure on health systems, agriculture, and energy grids.' },
  { icon: <CloudRain size={22} />, title: 'Extreme Weather', text: 'Storms, floods, and droughts are becoming more frequent and more severe.' },
  { icon: <Sprout size={22} />, title: 'Agricultural Impacts', text: 'Shifting rainfall and temperature patterns threaten crop yields and food security.' },
  { icon: <PawPrint size={22} />, title: 'Biodiversity Loss', text: 'Habitats are changing faster than many species can adapt, increasing extinction risk.' },
]

export default function ClimateInfo() {
  return (
    <>
      <section className="section section--tight">
        <div className="container">
          <div className="eyebrow"><BookOpen size={14} /> Climate Awareness</div>
          <h2 className="section-heading">What is climate change?</h2>
          <div className="prose-block" style={{ marginTop: 18 }}>
            <p>
              Climate change refers to long-term shifts in temperatures and weather patterns.
              While some variation is natural, human activity has been the main driver of
              climate change since the 1800s, primarily through burning fossil fuels that
              release heat-trapping greenhouse gases into the atmosphere.
            </p>
            <p>
              These gases build up in the atmosphere like a blanket around the Earth, trapping
              the sun's heat and raising global temperatures. Over time, this warming affects
              everything from ocean currents and ice caps to rainfall patterns and ecosystems
              — making awareness and informed action increasingly important.
            </p>
          </div>
        </div>
      </section>

      <section className="section section--tight" style={{ paddingTop: 0 }}>
        <div className="container">
          <div className="divider-label"><span>MAJOR CAUSES</span></div>
          <div className="info-grid">
            {causes.map((c) => (
              <div className="card card--hover info-card" key={c.title}>
                <div className="info-card__icon">{c.icon}</div>
                <div className="info-card__title">{c.title}</div>
                <p className="info-card__text">{c.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section section--tight" style={{ paddingTop: 0 }}>
        <div className="container">
          <div className="divider-label"><span>MAJOR EFFECTS</span></div>
          <div className="info-grid">
            {effects.map((e) => (
              <div className="card card--hover info-card info-card--effect" key={e.title}>
                <div className="info-card__icon">{e.icon}</div>
                <div className="info-card__title">{e.title}</div>
                <p className="info-card__text">{e.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section section--tight" style={{ paddingTop: 0 }}>
        <div className="container">
          <div className="divider-label"><span>WHY AWARENESS MATTERS</span></div>
          <div className="prose-block">
            <p>
              Awareness is the first step toward action. This survey found that while{' '}
              77.4% of respondents have heard about climate change, meaningful understanding
              still varies — the average self-rated knowledge score was only 3.34 out of 5.
            </p>
            <p>
              The more people understand the causes and effects of climate change, the better
              equipped communities are to support policies, adopt sustainable habits, and hold
              institutions accountable. Awareness turns concern into action.
            </p>
          </div>
        </div>
      </section>
    </>
  )
}
