import {
  PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, LabelList,
} from 'recharts'
import { Users, Globe2, ShieldAlert, Brain, Filter, Sparkles, RefreshCw, Radio } from 'lucide-react'
import StatCard from '../components/StatCard.jsx'
import ChartCard from '../components/ChartCard.jsx'
import InsightCard from '../components/InsightCard.jsx'
import { useSurveyData } from '../hooks/useSurveyData.js'
import { CHART_COLORS } from '../data/surveyData.js'

function DonutTooltip({ active, payload }) {
  if (!active || !payload?.length) return null
  const d = payload[0].payload
  return (
    <div style={{ background: 'var(--navy)', color: '#fff', padding: '8px 12px', borderRadius: 8, fontSize: 13 }}>
      <strong>{d.name}</strong>: {d.value} ({d.percent}%)
    </div>
  )
}

function BarTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null
  const d = payload[0].payload
  return (
    <div style={{ background: 'var(--navy)', color: '#fff', padding: '8px 12px', borderRadius: 8, fontSize: 13 }}>
      <strong>{d.name || label}</strong>: {d.value} ({d.percent}%)
    </div>
  )
}

function Donut({ data }) {
  return (
    <ResponsiveContainer width="100%" height={220}>
      <PieChart>
        <Pie
          data={data}
          dataKey="value"
          nameKey="name"
          innerRadius={62}
          outerRadius={92}
          paddingAngle={3}
          animationDuration={900}
        >
          {data.map((entry, i) => (
            <Cell key={entry.name} fill={CHART_COLORS[i % CHART_COLORS.length]} stroke="none" />
          ))}
        </Pie>
        <Tooltip content={<DonutTooltip />} />
      </PieChart>
    </ResponsiveContainer>
  )
}

function legendFor(data) {
  return data.map((d, i) => ({
    name: d.name,
    value: d.value,
    suffix: ` (${d.percent}%)`,
    color: CHART_COLORS[i % CHART_COLORS.length],
  }))
}

export default function Dashboard() {
  const { data, isLive, isConfigured, loading, error, lastUpdated, refresh } = useSurveyData()
  const {
    TOTAL_RESPONDENTS, AWARENESS_RESPONDENTS, HEARD_ABOUT_PERCENT, SERIOUS_AGREE_PERCENT,
    AVERAGE_KNOWLEDGE_RATING, ageData, genderData, occupationData, heardAboutData,
    knowledgeData, sourceData, seriousnessData, concernData, keyInsights,
  } = data

  return (
    <section className="section">
      <div className="container">
        <div className="eyebrow"><Sparkles size={14} /> Interactive Survey Dashboard</div>
        <h2 className="section-heading">Survey results at a glance</h2>
        <p className="section-sub">
          {isLive ? 'Live view' : 'View'} of the Climate Change Awareness Survey — {TOTAL_RESPONDENTS} demographic
          responses, {AWARENESS_RESPONDENTS} awareness &amp; opinion responses.
        </p>

        {/* Data source status */}
        <div className="data-status">
          {isConfigured ? (
            <>
              <span className={'data-status__badge' + (isLive ? ' data-status__badge--live' : '')}>
                <Radio size={12} /> {isLive ? 'Live from Google Sheet' : 'Connecting…'}
              </span>
              {lastUpdated && (
                <span className="data-status__time">Updated {lastUpdated.toLocaleTimeString()}</span>
              )}
              {error && <span className="data-status__error">{error} — showing last available data.</span>}
              <button className="data-status__refresh" onClick={refresh} disabled={loading}>
                <RefreshCw size={13} className={loading ? 'spin' : ''} /> Refresh
              </button>
            </>
          ) : (
            <span className="data-status__badge">Static demo data — connect a Google Sheet in src/data/liveConfig.js to go live</span>
          )}
        </div>

        {/* Filter bar — disabled, labeled as future functionality since the
            aggregated survey data does not support cross-tabulated filtering */}
        <div className="filter-bar" style={{ marginTop: 20 }}>
          <div className="filter-bar__label"><Filter size={15} /> Filter by</div>
          <select disabled defaultValue="age"><option value="age">Age group</option></select>
          <select disabled defaultValue="gender"><option value="gender">Gender</option></select>
          <select disabled defaultValue="occupation"><option value="occupation">Occupation</option></select>
          <span className="filter-bar__note">Coming soon — requires cross-tabulated survey data</span>
        </div>

        {/* KPI cards */}
        <div className="kpi-grid">
          <StatCard icon={<Users size={20} />} value={TOTAL_RESPONDENTS} label="Total Respondents" />
          <StatCard
            icon={<Globe2 size={20} />}
            iconBg="#E7F3FB" iconColor="var(--teal)"
            value={`${HEARD_ABOUT_PERCENT}%`}
            label="Heard About Climate Change"
          />
          <StatCard
            icon={<ShieldAlert size={20} />}
            iconBg="#FCEEE8" iconColor="var(--orange)"
            value={`${SERIOUS_AGREE_PERCENT}%`}
            label="Consider It a Serious Issue"
          />
          <StatCard
            icon={<Brain size={20} />}
            value={`${AVERAGE_KNOWLEDGE_RATING} / 5`}
            label="Average Knowledge Rating"
          />
        </div>

        {/* Survey insights: demographics */}
        <div className="divider-label" style={{ marginTop: 56 }}>
          <span>SURVEY INSIGHTS — DEMOGRAPHICS ({TOTAL_RESPONDENTS} RESPONSES)</span>
        </div>
        <div className="chart-grid">
          <ChartCard title="Age Distribution" meta={`${TOTAL_RESPONDENTS} responses`} legend={legendFor(ageData)}>
            <Donut data={ageData} />
          </ChartCard>
          <ChartCard title="Gender Distribution" meta={`${TOTAL_RESPONDENTS} responses`} legend={legendFor(genderData)}>
            <Donut data={genderData} />
          </ChartCard>
          <ChartCard title="Occupation" meta={`${TOTAL_RESPONDENTS} responses`} legend={legendFor(occupationData)}>
            <Donut data={occupationData} />
          </ChartCard>
          <ChartCard title="Heard About Climate Change" meta={`${TOTAL_RESPONDENTS} responses`} legend={legendFor(heardAboutData)}>
            <Donut data={heardAboutData} />
          </ChartCard>
        </div>

        {/* Knowledge & information */}
        <div className="divider-label" style={{ marginTop: 56 }}>
          <span>KNOWLEDGE &amp; INFORMATION ({AWARENESS_RESPONDENTS} RESPONSES)</span>
        </div>
        <div className="chart-grid">
          <ChartCard
            title="Climate Knowledge Rating"
            meta='"How would you rate your knowledge of climate change?" (1–5)'
          >
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={knowledgeData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E1E9E4" />
                <XAxis dataKey="rating" tick={{ fontSize: 12.5, fill: '#4B5D56' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 12.5, fill: '#4B5D56' }} axisLine={false} tickLine={false} />
                <Tooltip content={<BarTooltip />} cursor={{ fill: 'rgba(27,94,63,0.06)' }} />
                <Bar dataKey="value" name="Respondents" radius={[8, 8, 0, 0]} animationDuration={900}>
                  {knowledgeData.map((d) => (
                    <Cell key={d.rating} fill="var(--forest-green)" />
                  ))}
                  <LabelList dataKey="percent" position="top" formatter={(v) => `${v}%`} style={{ fontSize: 11, fill: '#4B5D56' }} />
                </Bar>
              </BarChart>
            </ResponsiveContainer>
            <p style={{ marginTop: 6, fontSize: 13, color: 'var(--ink-soft)' }}>
              Average knowledge rating: <strong style={{ color: 'var(--navy)' }}>{AVERAGE_KNOWLEDGE_RATING} / 5</strong>
            </p>
          </ChartCard>

          <ChartCard
            title="Sources of Climate Information"
            meta="Multiple choice — percentages add up to more than 100%"
          >
            <ResponsiveContainer width="100%" height={280}>
              <BarChart
                data={sourceData}
                layout="vertical"
                margin={{ top: 5, right: 30, left: 10, bottom: 0 }}
              >
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#E1E9E4" />
                <XAxis type="number" tick={{ fontSize: 12, fill: '#4B5D56' }} axisLine={false} tickLine={false} unit="%" />
                <YAxis
                  type="category"
                  dataKey="name"
                  width={130}
                  tick={{ fontSize: 12.5, fill: '#14251F' }}
                  axisLine={false}
                  tickLine={false}
                />
                <Tooltip content={<BarTooltip />} cursor={{ fill: 'rgba(31,158,139,0.06)' }} />
                <Bar dataKey="percent" name="Percent" radius={[0, 8, 8, 0]} animationDuration={900}>
                  {sourceData.map((d) => (
                    <Cell key={d.name} fill={d.name === 'Social Media' ? 'var(--orange)' : 'var(--teal)'} />
                  ))}
                  <LabelList dataKey="percent" position="right" formatter={(v) => `${v}%`} style={{ fontSize: 11, fill: '#4B5D56' }} />
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>
        </div>

        {/* Climate concerns */}
        <div className="divider-label" style={{ marginTop: 56 }}>
          <span>CLIMATE CONCERNS ({AWARENESS_RESPONDENTS} RESPONSES)</span>
        </div>
        <div className="chart-grid">
          <ChartCard
            title="Is Climate Change a Serious Global Issue?"
            meta={`${SERIOUS_AGREE_PERCENT}% agree or strongly agree`}
            legend={legendFor(seriousnessData)}
          >
            <Donut data={seriousnessData} />
          </ChartCard>

          <ChartCard title="Most Concerning Climate Issue" meta="Highest-ranked issue leads the chart">
            <ResponsiveContainer width="100%" height={260}>
              <BarChart
                data={concernData}
                layout="vertical"
                margin={{ top: 5, right: 30, left: 10, bottom: 0 }}
              >
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#E1E9E4" />
                <XAxis type="number" tick={{ fontSize: 12, fill: '#4B5D56' }} axisLine={false} tickLine={false} unit="%" />
                <YAxis
                  type="category"
                  dataKey="name"
                  width={110}
                  tick={{ fontSize: 12.5, fill: '#14251F' }}
                  axisLine={false}
                  tickLine={false}
                />
                <Tooltip content={<BarTooltip />} cursor={{ fill: 'rgba(232,115,74,0.06)' }} />
                <Bar dataKey="percent" name="Percent" radius={[0, 8, 8, 0]} animationDuration={900}>
                  {concernData.map((d, i) => (
                    <Cell key={d.name} fill={i === 0 ? 'var(--deep-green)' : '#8FA398'} />
                  ))}
                  <LabelList dataKey="percent" position="right" formatter={(v) => `${v}%`} style={{ fontSize: 11, fill: '#4B5D56' }} />
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>
        </div>

        {/* Key insights */}
        <div className="divider-label" style={{ marginTop: 56 }}>
          <span>KEY INSIGHTS</span>
        </div>
        <div className="insight-grid">
          {keyInsights.map((text) => (
            <InsightCard key={text} text={text} />
          ))}
        </div>
      </div>
    </section>
  )
}
