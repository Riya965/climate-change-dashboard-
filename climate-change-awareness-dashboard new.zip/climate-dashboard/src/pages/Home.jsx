import { Link } from 'react-router-dom'
import { ArrowRight, ClipboardList, Users, Globe2, Brain, ShieldAlert } from 'lucide-react'
import { SURVEY_FORM_URL } from '../data/surveyData.js'
import { useSurveyData } from '../hooks/useSurveyData.js'

const CIRCUMFERENCE = 691 // 2 * PI * 110

export default function Home() {
  const { data } = useSurveyData()
  const { TOTAL_RESPONDENTS, AWARENESS_RESPONDENTS, HEARD_ABOUT_PERCENT, SERIOUS_AGREE_PERCENT, AVERAGE_KNOWLEDGE_RATING } = data
  const offset = CIRCUMFERENCE * (1 - HEARD_ABOUT_PERCENT / 100)

  return (
    <>
      <section className="hero">
        <div className="contour-bg" />
        <div className="hero__inner">
          <div>
            <div className="eyebrow">
              <Globe2 size={14} /> College Project · Survey-Based Dashboard
            </div>
            <h1 className="hero__title">
              Climate Change <span>Awareness</span>
            </h1>
            <p className="hero__quote">
              "Understanding awareness today to build a sustainable tomorrow."
            </p>

            <div className="hero__actions">
              <Link to="/dashboard" className="btn btn--primary">
                Explore Dashboard <ArrowRight size={17} />
              </Link>
              <a
                href={SURVEY_FORM_URL}
                target="_blank"
                rel="noreferrer"
                className="btn btn--secondary"
              >
                <ClipboardList size={17} /> Take Survey
              </a>
            </div>

            <div className="hero__stats">
              <div>
                <div className="hero__stat-num">{TOTAL_RESPONDENTS}</div>
                <div className="hero__stat-label">Total respondents</div>
              </div>
              <div>
                <div className="hero__stat-num">{HEARD_ABOUT_PERCENT}%</div>
                <div className="hero__stat-label">Heard of climate change</div>
              </div>
              <div>
                <div className="hero__stat-num">{SERIOUS_AGREE_PERCENT}%</div>
                <div className="hero__stat-label">Say it's a serious issue</div>
              </div>
            </div>
          </div>

          <div className="hero__visual">
            <div className="ring-card">
              <svg viewBox="0 0 240 240">
                <circle cx="120" cy="120" r="110" fill="none" stroke="#E7F5EE" strokeWidth="18" />
                <circle
                  className="ring-progress"
                  style={{ '--ring-offset': offset }}
                  cx="120"
                  cy="120"
                  r="110"
                  fill="none"
                  stroke="#1B5E3F"
                  strokeWidth="18"
                  strokeLinecap="round"
                  transform="rotate(-90 120 120)"
                />
              </svg>
              <div className="ring-card__center">
                <div className="ring-card__pct">{HEARD_ABOUT_PERCENT}%</div>
                <p className="ring-card__label">of respondents have heard about climate change</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="section section--tight">
        <div className="container">
          <div className="eyebrow"><Brain size={14} /> Why This Project</div>
          <h2 className="section-heading">A real survey, read like a real dashboard</h2>
          <p className="section-sub">
            This project analyzes {TOTAL_RESPONDENTS} responses from the "Climate Change
            Awareness Survey" to understand how much people know about climate change,
            where they learn about it, and how seriously they take it — presented as an
            interactive analytics experience rather than a static form summary.
          </p>

          <div className="kpi-grid" style={{ marginTop: 40 }}>
            <div className="card card--hover kpi-card">
              <div className="kpi-card__icon" style={{ background: 'var(--pale-green)', color: 'var(--forest-green)' }}>
                <Users size={20} />
              </div>
              <div>
                <div className="kpi-card__value">{TOTAL_RESPONDENTS}</div>
                <div className="kpi-card__label">Survey respondents</div>
              </div>
            </div>
            <div className="card card--hover kpi-card">
              <div className="kpi-card__icon" style={{ background: '#E7F3FB', color: 'var(--teal)' }}>
                <Globe2 size={20} />
              </div>
              <div>
                <div className="kpi-card__value">{HEARD_ABOUT_PERCENT}%</div>
                <div className="kpi-card__label">Aware of climate change</div>
              </div>
            </div>
            <div className="card card--hover kpi-card">
              <div className="kpi-card__icon" style={{ background: '#FCEEE8', color: 'var(--orange)' }}>
                <ShieldAlert size={20} />
              </div>
              <div>
                <div className="kpi-card__value">{SERIOUS_AGREE_PERCENT}%</div>
                <div className="kpi-card__label">Call it a serious issue</div>
              </div>
            </div>
            <div className="card card--hover kpi-card">
              <div className="kpi-card__icon" style={{ background: 'var(--pale-green)', color: 'var(--forest-green)' }}>
                <Brain size={20} />
              </div>
              <div>
                <div className="kpi-card__value">{AVERAGE_KNOWLEDGE_RATING} / 5</div>
                <div className="kpi-card__label">Average knowledge rating</div>
              </div>
            </div>
          </div>
          <p style={{ marginTop: 18, fontSize: 13, color: 'var(--ink-soft)' }}>
            Knowledge, information-source, seriousness, and concern questions were answered by
            a subset of {AWARENESS_RESPONDENTS} respondents.
          </p>
        </div>
      </section>
    </>
  )
}
