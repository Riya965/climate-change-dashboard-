import {
  Lightbulb, Bus, Ban, Recycle, TreePine, Droplets, Sun, Utensils, Leaf,
} from 'lucide-react'

const actions = [
  { icon: <Lightbulb size={20} />, title: 'Save Energy', text: 'Turn off lights and appliances when they are not needed.' },
  { icon: <Bus size={20} />, title: 'Use Public Transport', text: 'Reduce emissions by using buses, trains, cycling, or walking.' },
  { icon: <Ban size={20} />, title: 'Reduce Plastic', text: 'Avoid unnecessary single-use plastic in daily life.' },
  { icon: <Recycle size={20} />, title: 'Reuse & Recycle', text: 'Give products a second life and recycle responsibly.' },
  { icon: <TreePine size={20} />, title: 'Plant Trees', text: 'Protect existing forests and increase green spaces.' },
  { icon: <Droplets size={20} />, title: 'Save Water', text: 'Avoid unnecessary water wastage at home and at work.' },
  { icon: <Sun size={20} />, title: 'Choose Renewable Energy', text: 'Support clean energy sources such as solar and wind.' },
  { icon: <Utensils size={20} />, title: 'Reduce Food Waste', text: 'Plan meals and store food properly to cut down on waste.' },
]

export default function ClimateAction() {
  return (
    <section className="section">
      <div className="container">
        <div className="eyebrow"><Leaf size={14} /> Climate Action</div>
        <h2 className="section-heading">Practical actions anyone can take</h2>
        <p className="section-sub">
          Awareness matters most when it leads to action. Here are simple, everyday habits
          that reduce environmental impact.
        </p>

        <div className="action-grid" style={{ marginTop: 40 }}>
          {actions.map((a) => (
            <div className="card card--hover action-card" key={a.title}>
              <div className="action-card__icon">{a.icon}</div>
              <div className="action-card__title">{a.title}</div>
              <p className="action-card__text">{a.text}</p>
            </div>
          ))}
        </div>

        <div className="action-banner">
          <div className="contour-bg" style={{ opacity: 0.25 }} />
          <h3>Small Actions Today, Better Tomorrow.</h3>
          <p>Every habit above, repeated by enough people, adds up to real change.</p>
        </div>
      </div>
    </section>
  )
}
