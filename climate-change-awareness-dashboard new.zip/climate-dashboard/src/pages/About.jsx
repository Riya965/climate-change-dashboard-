import { Info } from 'lucide-react'
import { useSurveyData } from '../hooks/useSurveyData.js'

export default function About() {
  const { data, isLive } = useSurveyData()
  const { TOTAL_RESPONDENTS, AWARENESS_RESPONDENTS } = data

  return (
    <section className="section">
      <div className="container">
        <div className="eyebrow"><Info size={14} /> About This Project</div>
        <h2 className="section-heading">Climate Change Awareness Using Interactive Dashboard</h2>

        <div className="about-grid" style={{ marginTop: 40 }}>
          <div className="prose-block">
            <p>
              <strong style={{ color: 'var(--navy)' }}>Objective.</strong> This project analyzes
              public awareness of climate change through a structured survey, presenting the
              findings as an interactive dashboard rather than a static report.
            </p>
            <p>
              <strong style={{ color: 'var(--navy)' }}>Methodology.</strong> Data was collected
              using a Google Form titled "Climate Change Awareness Survey." Demographic
              questions (age, gender, occupation, and prior awareness) received{' '}
              {TOTAL_RESPONDENTS} responses. Follow-up questions on knowledge, information
              sources, seriousness, and top concerns were answered by a subset of{' '}
              {AWARENESS_RESPONDENTS} respondents.
              {isLive && ' These figures update automatically as new responses come in.'}
            </p>
            <p>
              <strong style={{ color: 'var(--navy)' }}>Purpose of the dashboard.</strong> To turn
              raw survey responses into a clear, visual, and interactive story — helping viewers
              quickly understand how aware people are, what shapes that awareness, and how
              seriously climate change is perceived.
            </p>
          </div>

          <div>
            <div className="divider-label" style={{ marginTop: 0 }}><span>PROJECT DETAILS</span></div>
            <div className="meta-list">
              <div className="meta-row">
                <span className="meta-row__key">Total respondents</span>
                <span className="meta-row__val">{TOTAL_RESPONDENTS}</span>
              </div>
              <div className="meta-row">
                <span className="meta-row__key">Awareness-question respondents</span>
                <span className="meta-row__val">{AWARENESS_RESPONDENTS}</span>
              </div>
              <div className="meta-row">
                <span className="meta-row__key">Survey tool</span>
                <span className="meta-row__val">Google Forms</span>
              </div>
              <div className="meta-row">
                <span className="meta-row__key">Dashboard type</span>
                <span className="meta-row__val">{isLive ? 'Interactive, live-updating' : 'Interactive, client-side'}</span>
              </div>
            </div>

            <div className="divider-label" style={{ marginTop: 28 }}><span>TECHNOLOGY USED</span></div>
            <div className="tech-chips">
              {['React.js', 'Vite', 'JavaScript', 'Recharts', 'Lucide React', 'CSS3'].map((t) => (
                <span className="tech-chip" key={t}>{t}</span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
