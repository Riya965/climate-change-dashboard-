// ============================================================================
// Climate Change Awareness Survey — Source Data
// ----------------------------------------------------------------------------
// All figures below come directly from the "Climate Change Awareness Survey"
// Google Form results provided for this project. Nothing here is invented:
// demographic questions were answered by 53 respondents, and the awareness /
// opinion questions were answered by a subset of 41 respondents.
// Do not edit these numbers unless the underlying survey data changes.
// ============================================================================

export const TOTAL_RESPONDENTS = 53;
export const AWARENESS_RESPONDENTS = 41;

// The real Google Form used for this survey.
export const SURVEY_FORM_URL = 'https://forms.gle/LpibqTECsCEzYqs1A';

// ---- Demographics (53 responses) ------------------------------------------

export const ageData = [
  { name: 'Below 18', value: 5, percent: 9.4 },
  { name: '18–25', value: 43, percent: 81.1 },
  { name: '26–35', value: 5, percent: 9.4 },
  { name: 'Above 45', value: 0, percent: 0 },
];

export const genderData = [
  { name: 'Male', value: 29, percent: 54.7 },
  { name: 'Female', value: 24, percent: 45.3 },
];

export const occupationData = [
  { name: 'Student', value: 30, percent: 56.6 },
  { name: 'Working Professional', value: 13, percent: 24.5 },
  { name: 'Business Owner', value: 3, percent: 5.7 },
  { name: 'Other', value: 7, percent: 13.2 },
];

// ---- Awareness KPI (53 responses) ------------------------------------------

export const heardAboutData = [
  { name: 'Yes', value: 41, percent: 77.4 },
  { name: 'No', value: 12, percent: 22.6 },
];

export const HEARD_ABOUT_PERCENT = 77.4;

// ---- Knowledge rating (41 responses) ---------------------------------------
// "How would you rate your knowledge of climate change?" (1 = lowest, 5 = highest)

export const knowledgeData = [
  { rating: '1', value: 3, percent: 7.3 },
  { rating: '2', value: 2, percent: 4.9 },
  { rating: '3', value: 20, percent: 48.8 },
  { rating: '4', value: 10, percent: 24.4 },
  { rating: '5', value: 6, percent: 14.6 },
];

export const AVERAGE_KNOWLEDGE_RATING = 3.34;

// ---- Source of information (41 responses, multiple choice — sums > 100%) --

export const sourceData = [
  { name: 'Social Media', value: 30, percent: 73.2 },
  { name: 'TV/News', value: 18, percent: 43.9 },
  { name: 'School/College', value: 13, percent: 31.7 },
  { name: 'Newspapers', value: 12, percent: 29.3 },
  { name: 'Friends/Family', value: 8, percent: 19.5 },
  { name: 'Government Websites', value: 6, percent: 14.6 },
  { name: 'Other', value: 5, percent: 12.2 },
];

// ---- Seriousness of climate change (41 responses) --------------------------

export const seriousnessData = [
  { name: 'Strongly Agree', value: 15, percent: 36.6 },
  { name: 'Agree', value: 20, percent: 48.8 },
  { name: 'Neutral', value: 5, percent: 12.2 },
  { name: 'Disagree', value: 1, percent: 2.4 },
  { name: 'Strongly Disagree', value: 0, percent: 0 },
];

// Strongly Agree + Agree = 35 / 41 = 85.4%
export const SERIOUS_AGREE_PERCENT = 85.4;

// ---- Most concerning climate issue (41 responses) --------------------------

export const concernData = [
  { name: 'Global Warming', value: 22, percent: 53.7 },
  { name: 'Air Pollution', value: 10, percent: 24.4 },
  { name: 'Deforestation', value: 3, percent: 7.3 },
  { name: 'Water Scarcity', value: 4, percent: 9.8 },
  { name: 'Floods', value: 2, percent: 4.9 },
  { name: 'Heatwaves', value: 0, percent: 0 },
];

// ---- Auto-generated key insights (derived only from the data above) -------

export const keyInsights = [
  'Most respondents (81.1%) are between 18 and 25 years old.',
  '77.4% of respondents have heard about climate change before.',
  '85.4% agree that climate change is a serious global issue.',
  'Social media is the most common source of climate information, cited by 73.2% of respondents.',
  'Global warming is the biggest concern, selected by 53.7% of respondents.',
];

// ---- Chart palette ----------------------------------------------------------
// Shared across all charts so every donut/bar segment stays visually consistent.

export const CHART_COLORS = [
  '#1B5E3F', // forest green
  '#1F9E8B', // teal
  '#4FD1A5', // light green
  '#0A1A2F', // dark navy
  '#E8734A', // orange accent
  '#7FB3D5', // muted blue (extra category)
  '#8FA398', // sage (extra category)
];
