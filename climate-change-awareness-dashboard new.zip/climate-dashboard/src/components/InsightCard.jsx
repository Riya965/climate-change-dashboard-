import { Sparkles } from 'lucide-react'

export default function InsightCard({ text, icon }) {
  return (
    <div className="card card--hover insight-card">
      <div className="insight-card__icon">
        {icon || <Sparkles size={17} />}
      </div>
      <p>{text}</p>
    </div>
  )
}
