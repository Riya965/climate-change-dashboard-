import { Leaf } from 'lucide-react'

export default function Footer() {
  return (
    <footer className="footer">
      <div className="container footer__inner">
        <div className="footer__brand">
          <Leaf size={16} />
          Climate Change Awareness Dashboard
        </div>
        <p>College project · Built from real survey data · 2026</p>
      </div>
    </footer>
  )
}
