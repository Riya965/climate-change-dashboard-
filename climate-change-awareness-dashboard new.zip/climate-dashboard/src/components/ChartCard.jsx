export default function ChartCard({ title, meta, full = false, children, legend }) {
  return (
    <div className={'card card--hover chart-card' + (full ? ' chart-card--full' : '')}>
      <div className="chart-card__head">
        <div className="chart-card__title">{title}</div>
        {meta && <div className="chart-card__meta">{meta}</div>}
      </div>
      {children}
      {legend && (
        <div className="legend-list">
          {legend.map((row) => (
            <div className="legend-row" key={row.name}>
              <div className="legend-row__left">
                <span className="legend-dot" style={{ background: row.color }} />
                {row.name}
              </div>
              <span className="legend-row__val">{row.value}{row.suffix || ''}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
