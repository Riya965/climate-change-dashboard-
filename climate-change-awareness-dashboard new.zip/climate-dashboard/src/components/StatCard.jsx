export default function StatCard({ icon, iconBg = 'var(--pale-green)', iconColor = 'var(--forest-green)', value, label, sub }) {
  return (
    <div className="card card--hover kpi-card">
      <div className="kpi-card__icon" style={{ background: iconBg, color: iconColor }}>
        {icon}
      </div>
      <div>
        <div className="kpi-card__value">{value}</div>
        <div className="kpi-card__label">{label}</div>
        {sub && <div className="kpi-card__sub">{sub}</div>}
      </div>
    </div>
  )
}
